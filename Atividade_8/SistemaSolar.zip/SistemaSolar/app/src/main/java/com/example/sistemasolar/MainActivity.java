package com.example.sistemasolar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {
    private ListView listView;
    private Adapter adapter;
    private static ArrayList<ItemList> itens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);
    }

@Override
protected void onResume() {
    super.onResume();
    String nomePlaneta = getIntent().getStringExtra("nomePlaneta");
    if (nomePlaneta != null) {
        remolvePlaneta(nomePlaneta);
    } else if (itens == null) {
        DadosMoki moki = new DadosMoki();
        itens = moki.getItens();
    }
    criarAdapter();
}

    private void remolvePlaneta(String nomePlaneta) {
        for (int i = 0; i < itens.size(); i++) {
            if (itens.get(i).getTexto().equals(nomePlaneta)) {
                itens.remove(i);
                break;
            }
        }
    }

    private void criarAdapter() {
        adapter = new Adapter(this, itens);
        listView.setAdapter(adapter);
        listView.setOnItemLongClickListener(this);
        listView.setOnItemClickListener(this);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        ItemList item = (ItemList) parent.getItemAtPosition(position);
        MyAlerDialog dialog = new MyAlerDialog(item.getTexto());
        dialog.show(getSupportFragmentManager(), "dialog");
        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, PlanetaActivity.class);
        ItemList item = (ItemList) parent.getItemAtPosition(position);
        intent.putExtra("planeta", item.getTexto());
        startActivity(intent);
    }
}