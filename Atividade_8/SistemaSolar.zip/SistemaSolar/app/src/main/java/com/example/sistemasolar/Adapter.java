package com.example.sistemasolar;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter extends BaseAdapter {
    private LayoutInflater inflater;
    private ArrayList<ItemList> itens;

    public Adapter(Context context, ArrayList<ItemList> itens) {
        this.inflater = LayoutInflater.from(context);
        this.itens = itens;
    }

    @Override
    public int getCount() {
        return itens.size();
    }

    @Override
    public ItemList getItem(int position) {
        return itens.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ItemList item = itens.get(position);
        convertView = inflater.inflate(R.layout.item_list, null);
        TextView txtTitle = convertView.findViewById(R.id.text);
        txtTitle.setText(item.getTexto());
        ImageView img = convertView.findViewById(R.id.image);
        img.setImageResource(item.getImagem());
        return convertView;
    }
}
