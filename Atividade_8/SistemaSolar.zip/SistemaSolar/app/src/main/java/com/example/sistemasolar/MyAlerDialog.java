package com.example.sistemasolar;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import java.util.Locale;

public class MyAlerDialog extends DialogFragment {
    private String nomePlaneta;

    public MyAlerDialog(String nomePlaneta) {
        this.nomePlaneta = nomePlaneta;
    }

    public MyAlerDialog() {
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
//        return super.onCreateDialog(savedInstanceState);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Deseja Excluir?")
                .setMessage("Deseja excluir o planeta "+nomePlaneta+"?")
                .setPositiveButton("Sim", (dialog, which) -> {
                    excluirPlaneta();})
                .setNegativeButton("Não", (dialog, which) -> {
                    Toast.makeText(getActivity(), "Operação cancelada", Toast.LENGTH_SHORT).show();
                });
        return builder.create();
    }

    private void excluirPlaneta() {
        Intent intent = new Intent(getActivity(), MainActivity.class);
        intent.putExtra("nomePlaneta", nomePlaneta);
        startActivity(intent);
    }
}
