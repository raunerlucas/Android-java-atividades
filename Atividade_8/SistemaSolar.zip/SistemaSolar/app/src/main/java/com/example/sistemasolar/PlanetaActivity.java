package com.example.sistemasolar;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PlanetaActivity extends AppCompatActivity {
    private TextView nomePlaneta, caracteristicasPlaneta;
    private ImageView imagemPlaneta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_planeta);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        nomePlaneta = findViewById(R.id.nome_planeta);
        caracteristicasPlaneta = findViewById(R.id.caract_planeta);
        imagemPlaneta = findViewById(R.id.img_planeta);

        String planeta = getIntent().getStringExtra("planeta");
        setplaneta(planeta);
    }

    private void setplaneta(String planeta) {
        Planeta p = DadosMoki.getPlanetasInfo(planeta);
        nomePlaneta.setText(p.getNome());
        String texto = "Caracteristica 1: " + p.getCaracteristica1() + "\n\n" +
                "Caracteristica 2: " + p.getCaracteristica2() + "\n\n" +
                "Caracteristica 3: " + p.getCaracteristica3();
        caracteristicasPlaneta.setText(texto);
        imagemPlaneta.setImageResource(p.getImg());
    }


}