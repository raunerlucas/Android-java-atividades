package com.example.sistemasolar;

import java.util.ArrayList;

public class DadosMoki {

    private static ArrayList<ItemList> itens = new ArrayList<>();

    public DadosMoki() {
        itens.add(new ItemList("Mercúrio", R.drawable.mercurio));
        itens.add(new ItemList("Vênus", R.drawable.venus));
        itens.add(new ItemList("Terra", R.drawable.planeta_terra));
        itens.add(new ItemList("Júpiter", R.drawable.jupiter));
        itens.add(new ItemList("Saturno", R.drawable.saturno));
    }

    public static Planeta getPlanetasInfo(String nome) {
       switch (nome) {
    case "Mercúrio":
        return new Planeta("Mercúrio",
                "É o planeta mais próximo do Sol.",
                "Temperaturas podem variar drasticamente, de até 430°C durante o dia a -180°C durante a noite.",
                "Mercúrio não tem uma atmosfera densa, o que contribui para a grande variação térmica e sua superfície estar exposta ao vácuo do espaço.",
                R.drawable.mercurio_img);
    case "Vênus":
        return new Planeta("Vênus",
                "Composta principalmente por dióxido de carbono e nuvens de ácido sulfúrico, criando um efeito estufa extremamente forte.",
                "A temperatura média é de cerca de 465°C, quente o suficiente para derreter chumbo.",
                "Vênus gira no sentido oposto à maioria dos planetas do sistema solar, o que significa que o Sol nasce no oeste e se põe no leste.",
                R.drawable.venus_img);
    case "Terra":
        return new Planeta("Terra",
                "A Terra é o único planeta conhecido que possui água em estado líquido em sua superfície.",
                "A atmosfera da Terra contém cerca de 21% de oxigênio, essencial para a vida como conhecemos.",
                "A Terra abriga uma grande variedade de organismos, com uma biodiversidade única no sistema solar.",
                R.drawable.terra_img);
    case "Júpiter":
        return new Planeta("Júpiter",
                "Júpiter é o maior planeta do sistema solar, com um diâmetro de cerca de 143.000 km.",
                "Uma tempestade permanente na atmosfera de Júpiter, maior que a Terra.",
                "Júpiter é um gigante gasoso, composto principalmente de hidrogênio e hélio, com um núcleo provavelmente sólido.",
                R.drawable.jupiter_img);
    case "Saturno":
        return new Planeta("Saturno",
                "Saturno é famoso por seus belos anéis compostos principalmente por partículas de gelo e rocha.",
                "Como Júpiter, é composto principalmente de hidrogênio e hélio.",
                "Saturno tem pelo menos 83 luas confirmadas, incluindo Titã, que é maior que o planeta Mercúrio.",
                R.drawable.saturno_img);
    default:
        return null;
}
    }

    public static ArrayList<ItemList> getItens() {
        return itens;
    }
}
