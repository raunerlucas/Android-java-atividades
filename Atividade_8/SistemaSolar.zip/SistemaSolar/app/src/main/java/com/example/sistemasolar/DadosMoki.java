package com.example.sistemasolar;

import android.content.Context;

import java.util.ArrayList;

public class DadosMoki {

    private static ArrayList<ItemList> itens = new ArrayList<>();

    public DadosMoki() {
        itens.add(new ItemList("Mercúrio", R.drawable.mercurio));
        itens.add(new ItemList("Vênus", R.drawable.venus));
        itens.add(new ItemList("Terra", R.drawable.planeta_terra));
        itens.add(new ItemList("Júpiter", R.drawable.jupiter));
        itens.add(new ItemList("Saturno", R.drawable.saturno));
    }

    public static Planeta getPlanetasInfo(Context context, String nome) {
        switch (nome) {
            case "Mercúrio":
                return new Planeta(context.getString(R.string.mercurio),
                        context.getString(R.string.mercurio_info),
                        context.getString(R.string.mercurio_temp),
                        context.getString(R.string.mercurio_atm),
                        R.drawable.mercurio_img);
            case "Vênus":
                return new Planeta(context.getString(R.string.venus),
                        context.getString(R.string.venus_info),
                        context.getString(R.string.venus_temp),
                        context.getString(R.string.venus_rot),
                        R.drawable.venus_img);
            case "Terra":
                return new Planeta(context.getString(R.string.terra),
                        context.getString(R.string.terra_info),
                        context.getString(R.string.terra_atm),
                        context.getString(R.string.terra_bio),
                        R.drawable.terra_img);
            case "Júpiter":
                return new Planeta(context.getString(R.string.jupiter),
                        context.getString(R.string.jupiter_info),
                        context.getString(R.string.jupiter_temp),
                        context.getString(R.string.jupiter_comp),
                        R.drawable.jupiter_img);
            case "Saturno":
                return new Planeta(context.getString(R.string.saturno),
                        context.getString(R.string.saturno_info),
                        context.getString(R.string.saturno_comp),
                        context.getString(R.string.saturno_luas),
                        R.drawable.saturno_img);
            default:
                return null;
        }
    }

    public static ArrayList<ItemList> getItens() {
        return itens;
    }
}
